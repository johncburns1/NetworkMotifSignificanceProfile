These files are from http://www.weizmann.ac.il/mcb/UriAlon/download/collection-complex-networks
("Electronic circuits - s208_st.txt , s420_st.txt , s838_st.txt
(more electronic circuits can be found at: ISCAS 89, see also: Science 2004, pdf)"

The additional links are:
http://www.cbl.ncsu.edu/CBL_Docs/iscas89.html
http://www.weizmann.ac.il/mcb/UriAlon/sites/mcb.UriAlon/files/uploads/CollectionsOfComplexNetwroks/superfamilies_of_evolved_and_designed_networks.pdf
