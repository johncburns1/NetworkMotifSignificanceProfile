These files are from http://www.weizmann.ac.il/mcb/UriAlon/download/collection-complex-networks
("Languages: word adjacency networks - English , French , Spanish , Japanese (see also: Science 2004, pdf)")

