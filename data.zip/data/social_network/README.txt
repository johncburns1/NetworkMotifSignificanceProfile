These files are from http://www.weizmann.ac.il/mcb/UriAlon/download/collection-complex-networks
(the part "Social networks of positive sentiment - social1Inter_st.txt , social3Inter_st.txt (see also: Science 2004, pdf)")
Note that the names on the links are different:
social1Inter_st.txt  is actually prisoninter_st.txt
social3Inter_st.txt  is actually leader2inter_st.txt
